# FordGoBikeTrip Data
## by Anuoluwapo Babalola


## Dataset

This data set includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area. 

Factors to consider include:

Duration in seconds of most trip
Age and gender of most riders
If the above depend on if a user is a subscriber or customer


## Summary of Findings

After visualizing my data, I discoverd the following:
The highest duration is 500 seconds
There are more male members than female and other gender
Most members fall between the age 30 and 40
Most of the users are subscibers
Most people do not share all trip
Most members are male subscribers
Most male members do not share all trip
Most subscribers do not share all trip
Most customers age between the age 30 and 40
Customers spend more duration than subscribers
We have more female gender between age 30 and 40
There is no change in the quartile of the female gender compared to the male and other gender
Customers of the other gender spend more duration than the male and female gender
Users who share trip for all and do not share trip for all are almost within the same age bracket
Customers who do not share trip for all spend more duration compared to subscribers


## Key Insights for Presentation

I would present the following insights:
There is a sharp difference between the male and female users both customers and subscribers
We have more female gender between age 30 and 40
We can see that customers of the other gender spend more duration than the male and female gender